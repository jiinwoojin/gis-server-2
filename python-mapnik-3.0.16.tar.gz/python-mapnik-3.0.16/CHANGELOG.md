# Mapnik Python

# Version 0.1.0

 - Intial python bindings seperate from those of the core mapnik code
 - For changes previous to this please see the core mapnik changelog
