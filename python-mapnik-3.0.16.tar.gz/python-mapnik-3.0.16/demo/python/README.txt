This directory contains a sample python script implementing the Mapnik API.

The script is thoroughly commented and also acts as a mini tutorial.  Reading
it should get you on your way, and you can use it as a base for your work.

You must compile and install mapnik and the python bindings FIRST.

Once this is done, run it:

/path/to/python rundemo.py

If all goes well, it should render 2 map images:

demo.jpg
demo.png

Have a look!

Cheers,
J.F.
